const blogsData = require('./blogs')
const userData = require('./users')

module.exports = {
    blogs: blogsData,
    users: userData
}